Map data (c) OpenStreetMap contributors, https://www.openstreetmap.org
Extracts created by BBBike, https://extract.bbbike.org
osmium2shape by Geofabrik, https://geofabrik.de


Please read the OSM wiki how to use shape files.

  https://wiki.openstreetmap.org/wiki/Shapefiles


This shape file was created on: Thu  4 Sep 07:43:58 UTC 2025
GPS rectangle coordinates (lng,lat): 41.7983,9.5673 x 41.8972,9.6424
Script URL: https://extract.bbbike.org/?sw_lng=41.7983&sw_lat=9.5673&ne_lng=41.8972&ne_lat=9.6424&format=shp.zip&city=Dire+Dawa%2C+Ethiopia&lang=en
Name of area: Dire Dawa, Ethiopia


We appreciate any feedback, suggestions and a donation!
You can support us via PayPal or bank wire transfer.

  https://extract.bbbike.org/community.html

You can donate any free amount you want. We are happy for every donation,
for 5, 10, 20, or 50 Euro. Whatever you think the service is worth for you,
or you can afford. We need to raise 20 Euro (25 USD) by the end of the day or
600 Euro (700 USD) per month to cover the server costs.
Your donation helps to pay for hosting the service. Many thanks!

thanks, Wolfram Schneider

--
BBBike professional plans: https://extract.bbbike.org/support.html
Planet.osm extracts: https://extract.bbbike.org
BBBike Map Compare: https://mc.bbbike.org
